sap.ui.define(["demo/manageproducts/controller/BaseController"], function (Controller) {
    "use strict";

    return Controller.extend("demo.manageproducts.controller.MainView", {});
});
